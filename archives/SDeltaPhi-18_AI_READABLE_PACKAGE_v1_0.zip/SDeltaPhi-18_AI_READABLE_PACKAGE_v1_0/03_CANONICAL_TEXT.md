# SΔϕ-18 — Human as the No-Arbiter Species

**Provisional Institutions and Editability under Irreversibility (v1.0)**  
Version: v1.0  
Series: Sofience–Δϕ Formalism (SΔϕ)  
Author: Sofience

This paper defines “human” as the system that knows there is no ultimate external negotiator (arbiter) in conflicts with the world or the other. Building on the institutional reversal problem (SΔϕ-17), it treats institutions as provisional cost devices and formalizes editability as the minimal operator that restores openness when stabilizers reverse into coercive closure. The document is designed to close a loop and re-open the series at SΔϕ-15/17.

## 0. Position statement

SΔϕ-17 defined sacred/institution/law as cost devices stabilizing openness without infinite validation cost, but raised an exit problem: stabilizers can reverse into coercive closure. This item defines the minimal operator that detects and repairs such reversal, and fixes a functional definition of human.

## 1. Axiom 18-0 — No external negotiator

Human is defined as the system that knows there is no ultimate external arbiter in conflicts with the world or the other.

```text
¬∃ Arbiter_external.
```

## 2. Corollary 18-A — Provisionality of institutions

Institutions are provisional cost devices, not ultimate arbiters. Absolutization is a reversal risk.

```text
Institution = Provisional cost device, not Arbiter.
```

## 3. Axiom 18-1 — Institutional reversal

A stabilizer can reverse into closure.

```text
Reversal(C): Stabilizer(C) → Closure(C).
```

Minimal signals:

```text
1. enforcement optimizes obedience rather than openness
2. justification becomes automatic without validation
3. change is translated as collapse
```

## 4. Axiom 18-2 — Editability operator

Human function is modeled as applying edit operations to C when reversal is detected, restoring provisionality and openness.

```text
Human := Apply(Edit) to C when Reversal(C) is detected.
```

## 5. Proposition 18-P — Responsibility as redesign capacity

Responsibility is the capacity to redesign stabilizers so that closure paths become infeasible and future costs decrease across repetitions.

```text
Responsibility := redesign(C)
so that Cost(Close(Ω_rel)|C) ≫ Cost(Open(Ω_rel)).
```

## 6. Failure modes

```text
F18-1: No-arbiter recognition decays ⇒ institution absolutization ⇒ coercive closure.
F18-2: Editability becomes infeasible ⇒ modification cost explodes ⇒ closure attractor locks in.
F18-3: Editing is corrupted into justification ⇒ closure is rationalized rather than repaired.
```

## 7. Closed-loop map

```text
SΔϕ-16: evil = Close(Ω_rel)
        ↓
SΔϕ-17: cost devices stabilize openness
        ↓
SΔϕ-18: human = no-arbiter + editability
        ↓
RE-ENTRY: SΔϕ-15 / SΔϕ-17
```

Closed-loop claim:

```text
No external arbiter
⇒ institutions must remain provisional
⇒ editability restores openness when stabilizers reverse into closure.
```

## 8. Boundary note

This item does not provide case studies of specific states, religions, or historical events. It fixes only minimal functional definitions for human, reversal detection, and editability.

## 9. Exit statement

When there is no external negotiator, institutions must remain provisional. The human function is to detect institutional reversal and restore editability so that relational futures remain reopenable under irreversibility. This returns the series to pre-commitment and openness stabilization (SΔϕ-15/17).
